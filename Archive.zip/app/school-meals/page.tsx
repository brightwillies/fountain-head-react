import PageLayout from "@/components/PageLayout";

const sidebar = (
  <>
    {/* Admission Links */}
    <div className="mb-6">
      <h4
        className="font-display text-base mb-3 pb-2"
        style={{ color: '#fff', borderBottom: '1px solid rgba(255,255,255,0.12)' }}
      >
        Student Zone
      </h4>
      <ul className="space-y-1">
        {[
          { label: 'School Clubs', href: '/school-clubs' },
          { label: 'School Meals', href: '/school-meals' },
           { label: "Our Rules", href: "/our-rules" },
        ].map((l) => (
          <li key={l.label}>
            <a href={l.href} className="font-body text-sm py-1.5 block transition-colors duration-200 hover:text-white" style={{ color: 'rgba(255,255,255,0.55)', textDecoration: 'none' }}>
              {l.label}
            </a>
          </li>
        ))}
      </ul>
    </div>

    {/* Curriculum Links */}
    <div className="mb-6">
      <h4
        className="font-display text-base mb-3 pb-2"
        style={{ color: '#fff', borderBottom: '1px solid rgba(255,255,255,0.12)' }}
      >
        Curriculum
      </h4>
      <ul className="space-y-1">
        {[
          { label: 'Crèche', href: '/creche-curriculum' },
          { label: 'Pre-School', href: '/pre-school-curriculum' },
          { label: 'Lower & Upper School', href: '/lower-upper-school-curriculum' },
          { label: 'Junior High School', href: '/junior-high-school-curriculum' },
        ].map((l) => (
          <li key={l.label}>
            <a href={l.href} className="font-body text-sm py-1.5 block transition-colors duration-200 hover:text-white" style={{ color: 'rgba(255,255,255,0.55)', textDecoration: 'none' }}>
              {l.label}
            </a>
          </li>
        ))}
      </ul>
    </div>

    {/* Apply CTA card */}
    <div className="p-6 mb-6" style={{ background: '#10147c', border: '1px solid rgba(201,168,76,0.25)' }}>
      <h4 className="font-display text-base mb-2" style={{ color: '#fff' }}>Apply for 2025–26</h4>
      <p className="font-body text-xs mb-4 leading-relaxed" style={{ color: 'rgba(255,255,255,0.55)' }}>
        Applications for the upcoming school year are open. Begin your FCS journey today.
      </p>
      <a href="/inquire" className="block text-center py-3 text-xs tracking-widest uppercase font-body font-semibold" style={{ background: '#fff', color: '#10147c', textDecoration: 'none' }}>
        Start Application
      </a>
    </div>

    {/* Contact card */}
    <div className="p-5" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)' }}>
      <h4 className="font-display text-base mb-3" style={{ color: 'white' }}>Contact Admission</h4>
      <div className="font-body text-xs space-y-2">
        <p style={{ color: 'rgba(255,255,255,0.60)' }}>+233 (0) 303 963 578</p>
        <p style={{ color: '#fff' }}>admission@fcs.edu.gh</p>
        <p style={{ color: 'rgba(255,255,255,0.60)' }}>Mon–Fri, 8:00 AM – 4:30 PM</p>
      </div>
    </div>
  </>
);

const meals = [
  { name: "Monday", image: "images/meals/monday.jpg" },
  { name: "Tuesday", image: "images/meals/tuesday.jpg" },
  { name: "Wednesday", image: "images/meals/wednesday.jpg" },
  { name: "Thursday", image: "images/meals/thursday.jpg" },
  { name: "Friday", image: "images/meals/friday.jpg" },
];

export default function AdmissionPage() {
  return (
    <PageLayout
      hero={{
        title: "School Meals",
        image:
          "https://images.unsplash.com/photo-1567168544813-cc03465b4fa8?w=1600&q=80",
      }}
      breadcrumbs={[{ label: "School Meals" }]}
      sidebar={sidebar}
    >
      {/* ── Dark navy content panel ── */}
      <div style={{ background: '#0a0e5c', margin: '0 -2rem', padding: '3rem 2rem' }}>

        {/* Section header */}
        <div className="mb-8">
          <span className="block w-10 h-0.5 mb-4" style={{ background: '#fff' }} />
          <span style={{ color: '#fff', fontSize: '11px', letterSpacing: '0.35em', textTransform: 'uppercase', fontFamily: 'var(--font-body)', display: 'block', marginBottom: '0.75rem' }}>
            Fountainhead Christian School
          </span>
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 300, color: 'white', lineHeight: 1.2, fontSize: 'clamp(1.8rem, 3.5vw, 3rem)', marginBottom: '1rem' }}>
            Discover Our School Meals
          </h2>
         
        </div>

        {/* Clubs grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-8">
          {meals.map((meal, index) => (
            <div
              key={index}
              className="group relative overflow-hidden cursor-pointer"
              style={{ aspectRatio: '4/3' }}
            >
              <img
                src={meal.image}
                alt={meal.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              {/* Gradient overlay */}
              <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.80) 0%, rgba(0,0,0,0.15) 50%, transparent 100%)' }} />
              {/* Gold border accent on hover */}
              <div className="absolute inset-0 border border-transparent group-hover:border-gold/40 transition-all duration-300" />
              {/* Club name */}
              <div className="absolute bottom-0 left-0 right-0 p-5 text-center">
                <h3 className="font-display text-white text-xl md:text-2xl font-semibold mb-2">
                  {meal.name}
                </h3>
                <div
                  className="mx-auto h-0.5 transition-all duration-300 group-hover:w-16"
                  style={{ background: '#fff', width: '2.5rem' }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* CTA Banner */}
        <div style={{ padding: '2.5rem', display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '1.5rem', background: 'rgba(201,168,76,0.10)', border: '1px solid rgba(201,168,76,0.25)' }}>
          <div>
            <h3 style={{ fontFamily: 'var(--font-display)', color: 'white', fontSize: '1.5rem', marginBottom: '0.25rem' }}>
              Ready to Take the First Step?
            </h3>
            <p style={{ color: 'rgba(255,255,255,0.50)', fontFamily: 'var(--font-body)', fontSize: '0.85rem' }}>
              Our admissions team is here to guide your family every step of the way.
            </p>
          </div>
          <a
            href="/inquire"
            style={{ flexShrink: 0, padding: '1rem 2rem', background: '#fff', color: '#10147c', fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: '0.7rem', letterSpacing: '0.15em', textTransform: 'uppercase', textDecoration: 'none', display: 'inline-block' }}
          >
            Inquire Now
          </a>
        </div>

      </div>{/* end dark panel */}
    </PageLayout>
  );
}