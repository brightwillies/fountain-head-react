import PageLayout from "@/components/PageLayout";

const sidebar = (
  <>
    {/* Admission Links */}
    <div className="mb-6">
      <h4 className="font-display text-base mb-3 pb-2" style={{ color: '#fff', borderBottom: '1px solid rgba(255,255,255,0.12)' }}>
        Admission
      </h4>
      <ul className="space-y-1">
        {[
          { label: 'Admission Overview', href: '/admission' },
          { label: 'Admission Policy', href: '/admission-policy' },
          { label: 'Payments ', href: '/payments' },
        ].map((l) => (
          <li key={l.label}>
            <a href={l.href} className="font-body text-sm py-1.5 block transition-colors duration-200 hover:text-white" style={{ color: 'rgba(255,255,255,0.55)', textDecoration: 'none' }}>
              {l.label}
            </a>
          </li>
        ))}
      </ul>
    </div>

    {/* Curriculum Links */}
    <div className="mb-6">
      <h4 className="font-display text-base mb-3 pb-2" style={{ color: '#fff', borderBottom: '1px solid rgba(255,255,255,0.12)' }}>
        Curriculum
      </h4>
      <ul className="space-y-1">
        {[
          { label: 'Crèche', href: '/creche-curriculum' },
          { label: 'Pre-School', href: '/pre-school-curriculum' },
          { label: 'Lower & Upper School', href: '/lower-upper-school-curriculum' },
          { label: 'Junior High School', href: '/junior-high-school-curriculum' },
        ].map((l) => (
          <li key={l.label}>
            <a href={l.href} className="font-body text-sm py-1.5 block transition-colors duration-200 hover:text-white" style={{ color: 'rgba(255,255,255,0.55)', textDecoration: 'none' }}>
              {l.label}
            </a>
          </li>
        ))}
      </ul>
    </div>

    {/* Apply CTA card */}
    <div className="p-6 mb-6" style={{ background: '#10147c', border: '1px solid rgba(201,168,76,0.25)' }}>
      <h4 className="font-display text-base mb-2" style={{ color: '#fff' }}>Apply for 2025–26</h4>
      <p className="font-body text-xs mb-4 leading-relaxed" style={{ color: 'rgba(255,255,255,0.55)' }}>
        Applications for the upcoming school year are open. Begin your FCS journey today.
      </p>
      <a href="/inquire" className="block text-center py-3 text-xs tracking-widest uppercase font-body font-semibold" style={{ background: '#fff', color: '#10147c', textDecoration: 'none' }}>
        Start Application
      </a>
    </div>

    {/* Contact card */}
    <div className="p-5" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)' }}>
      <h4 className="font-display text-base mb-3" style={{ color: 'white' }}>Contact Admission</h4>
      <div className="font-body text-xs space-y-2">
        <p style={{ color: 'rgba(255,255,255,0.60)' }}>+233 (0) 303 963 578</p>
        <p style={{ color: '#fff' }}>admission@fcs.edu.gh</p>
        <p style={{ color: 'rgba(255,255,255,0.60)' }}>Mon–Fri, 8:00 AM – 4:30 PM</p>
      </div>
    </div>
  </>
);

export default function AdmissionPage() {
  return (
    <PageLayout
      hero={{
        title: "PAYMENTS",

        image:
          "https://images.unsplash.com/photo-1567168544813-cc03465b4fa8?w=1600&q=80",
      }}
      breadcrumbs={[{ label: "Payments" }]}
      sidebar={sidebar}
    >
      {/* ── Dark navy content panel ── */}
      <div style={{ background: '#0a0e5c', margin: '0 -2rem', padding: '3rem 2rem' }}>

        {/* Section header */}
        <div className="mb-8">
          <span className="block w-10 h-0.5 mb-4" style={{ background: '#fff' }} />
          <span style={{ color: '#fff', fontSize: '11px', letterSpacing: '0.35em', textTransform: 'uppercase', fontFamily: 'var(--font-body)', display: 'block', marginBottom: '0.75rem' }}>
            Fountainhead Christian School
          </span>
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 300, color: 'white', lineHeight: 1.2, fontSize: 'clamp(1.8rem, 3.5vw, 3rem)', marginBottom: '1rem' }}>
           Payment  (2025 – 2026 ACADEMIC YEAR)
          </h2>
          <p style={{ color: 'rgba(255,255,255,0.65)', fontFamily: 'var(--font-body)', fontWeight: 300, fontSize: '0.95rem', lineHeight: 1.8, maxWidth: '42rem' }}>
         
         We require a non-refundable Cash Fee when submitting the required admission forms. Please make admission payments at our account’s office from Monday to Friday from 7:00am to 3:30pm. Contact us for more information.
          </p>
        </div>

        {/* Steps header */}
        <div className="mb-6">
          <span className="block w-10 h-0.5 mb-4" style={{ background: '#fff' }} />
          <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 300, color: 'white', fontSize: 'clamp(1.5rem, 2.5vw, 2.2rem)', marginBottom: '0.5rem' }}>
            Payment Policies
          </h2>
          <p style={{ color: 'rgba(255,255,255,0.50)', fontFamily: 'var(--font-body)', fontSize: '0.875rem' }}>
            Our process is straightforward and designed to be welcoming from your very first inquiry.
          </p>
        </div>

        {/* Steps list */}
        <div className="space-y-4 mb-12">
          {[
            { num: '01', title: 'Admission is recognized when payment of registration and school fees is made in full' },
            { num: '02', title: '100% (full payment) of the subsequent term fees must be made on or before the day of opening.' },
            { num: '03', title: "If by the middle of the term a pupil/student has not reported for school as a result of non-payment of fees he/she will be considered withdrawn and as such he/she will be taken off the record."},
            { num: '04', title: "We do not accept cash. All payments (school fees, feeding and Transportation fees) can be made into the following school’s account numbers at any Prudential Bank or Ecobank near you. "},
          ].map((step) => (
            <div
              key={step.num}
              className="flex gap-6 items-start p-6"
              style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.10)' }}
            >
              <span
                className="font-display font-bold flex-none"
                style={{ color: 'rgba(201,168,76,0.30)', fontSize: '3rem', lineHeight: 1 }}
              >
                {step.num}
              </span>
              <div className="flex items-center h-full">
                <h3 className="font-display text-white" style={{ fontSize: '1.1rem', lineHeight: 1.4 }}>
                  {step.title}
                </h3>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Banner */}
        <div style={{ padding: '2.5rem', display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '1.5rem', background: 'rgba(201,168,76,0.10)', border: '1px solid rgba(201,168,76,0.25)' }}>
          <div>
            <h3 style={{ fontFamily: 'var(--font-display)', color: 'white', fontSize: '1.5rem', marginBottom: '0.25rem' }}>
            Prudential Bank Details
            </h3>
            <p style={{ color: '#ffff', fontFamily: 'var(--font-body)', fontSize: '0.95rem' }}>
              School Fees: 0122001220012 <br/> 
              Feeding Fees: 0122001220023  <br/>
               Transportation Fees: 0122001220067
            </p>
          </div>
          
        </div>

      </div>{/* end dark panel */}
    </PageLayout>
  );
}